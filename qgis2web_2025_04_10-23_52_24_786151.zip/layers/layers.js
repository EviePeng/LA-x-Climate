var wms_layers = [];

var format_Median_Income_and_AMI_census_tract_0 = new ol.format.GeoJSON();
var features_Median_Income_and_AMI_census_tract_0 = format_Median_Income_and_AMI_census_tract_0.readFeatures(json_Median_Income_and_AMI_census_tract_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Median_Income_and_AMI_census_tract_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Median_Income_and_AMI_census_tract_0.addFeatures(features_Median_Income_and_AMI_census_tract_0);
var lyr_Median_Income_and_AMI_census_tract_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Median_Income_and_AMI_census_tract_0, 
                style: style_Median_Income_and_AMI_census_tract_0,
                popuplayertitle: 'Median_Income_and_AMI_(census_tract)',
                interactive: true,
    title: 'Median_Income_and_AMI_(census_tract)<br />\
    <img src="styles/legend/Median_Income_and_AMI_census_tract_0_0.png" /> 1 - 47192<br />\
    <img src="styles/legend/Median_Income_and_AMI_census_tract_0_1.png" /> 47192 - 61548<br />\
    <img src="styles/legend/Median_Income_and_AMI_census_tract_0_2.png" /> 61548 - 77866<br />\
    <img src="styles/legend/Median_Income_and_AMI_census_tract_0_3.png" /> 77866 - 100685<br />\
    <img src="styles/legend/Median_Income_and_AMI_census_tract_0_4.png" /> 100685 - 250001<br />' });
var format_Metro_2023_1 = new ol.format.GeoJSON();
var features_Metro_2023_1 = format_Metro_2023_1.readFeatures(json_Metro_2023_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Metro_2023_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Metro_2023_1.addFeatures(features_Metro_2023_1);
var lyr_Metro_2023_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Metro_2023_1, 
                style: style_Metro_2023_1,
                popuplayertitle: 'Metro_2023',
                interactive: true,
                title: '<img src="styles/legend/Metro_2023_1.png" /> Metro_2023'
            });
var format_Bus_2023_2 = new ol.format.GeoJSON();
var features_Bus_2023_2 = format_Bus_2023_2.readFeatures(json_Bus_2023_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Bus_2023_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Bus_2023_2.addFeatures(features_Bus_2023_2);
var lyr_Bus_2023_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Bus_2023_2, 
                style: style_Bus_2023_2,
                popuplayertitle: 'Bus_2023',
                interactive: true,
                title: '<img src="styles/legend/Bus_2023_2.png" /> Bus_2023'
            });

lyr_Median_Income_and_AMI_census_tract_0.setVisible(true);lyr_Metro_2023_1.setVisible(true);lyr_Bus_2023_2.setVisible(true);
var layersList = [lyr_Median_Income_and_AMI_census_tract_0,lyr_Metro_2023_1,lyr_Bus_2023_2];
lyr_Median_Income_and_AMI_census_tract_0.set('fieldAliases', {'tract': 'tract', 'med_hh_inc': 'med_hh_inc', 'med_hh_i_1': 'med_hh_i_1', 'ami_catego': 'ami_catego', 'below_med_': 'below_med_', 'below_60pc': 'below_60pc', 'below_mode': 'below_mode', 'sup_dist': 'sup_dist', 'csa': 'csa', 'spa': 'spa', 'ESRI_OID': 'ESRI_OID', 'Shape__Are': 'Shape__Are', 'Shape__Len': 'Shape__Len', });
lyr_Metro_2023_1.set('fieldAliases', {'fid': 'fid', 'VAR_ROUTE': 'VAR_ROUTE', 'VAR_IDENT': 'VAR_IDENT', 'VAR_DIREC': 'VAR_DIREC', 'VAR_DESCR': 'VAR_DESCR', 'layer': 'layer', 'path': 'path', 'year': 'year', });
lyr_Bus_2023_2.set('fieldAliases', {'fid': 'fid', 'Id': 'Id', 'shape_id': 'shape_id', 'route_id': 'route_id', 'agency_id': 'agency_id', 'rt_shrt_nm': 'rt_shrt_nm', 'rt_long_nm': 'rt_long_nm', 'route_desc': 'route_desc', 'route_type': 'route_type', 'rt_typ_txt': 'rt_typ_txt', 'route_url': 'route_url', 'rt_color': 'rt_color', 'rt_col_fmt': 'rt_col_fmt', 'rt_txt_col': 'rt_txt_col', 'rt_txt_fmt': 'rt_txt_fmt', 'OBJECTID': 'OBJECTID', 'SHAPE_Leng': 'SHAPE_Leng', 'layer': 'layer', 'path': 'path', });
lyr_Median_Income_and_AMI_census_tract_0.set('fieldImages', {'tract': 'TextEdit', 'med_hh_inc': 'Range', 'med_hh_i_1': 'Range', 'ami_catego': 'TextEdit', 'below_med_': 'TextEdit', 'below_60pc': 'TextEdit', 'below_mode': 'TextEdit', 'sup_dist': 'TextEdit', 'csa': 'TextEdit', 'spa': 'TextEdit', 'ESRI_OID': 'Range', 'Shape__Are': 'TextEdit', 'Shape__Len': 'TextEdit', });
lyr_Metro_2023_1.set('fieldImages', {'fid': 'TextEdit', 'VAR_ROUTE': 'TextEdit', 'VAR_IDENT': 'TextEdit', 'VAR_DIREC': 'TextEdit', 'VAR_DESCR': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', 'year': '', });
lyr_Bus_2023_2.set('fieldImages', {'fid': 'TextEdit', 'Id': 'TextEdit', 'shape_id': 'TextEdit', 'route_id': 'TextEdit', 'agency_id': 'TextEdit', 'rt_shrt_nm': 'TextEdit', 'rt_long_nm': 'TextEdit', 'route_desc': 'TextEdit', 'route_type': 'TextEdit', 'rt_typ_txt': 'TextEdit', 'route_url': 'TextEdit', 'rt_color': 'TextEdit', 'rt_col_fmt': 'TextEdit', 'rt_txt_col': 'TextEdit', 'rt_txt_fmt': 'TextEdit', 'OBJECTID': 'TextEdit', 'SHAPE_Leng': 'TextEdit', 'layer': 'TextEdit', 'path': 'TextEdit', });
lyr_Median_Income_and_AMI_census_tract_0.set('fieldLabels', {'tract': 'no label', 'med_hh_inc': 'no label', 'med_hh_i_1': 'no label', 'ami_catego': 'no label', 'below_med_': 'no label', 'below_60pc': 'no label', 'below_mode': 'no label', 'sup_dist': 'no label', 'csa': 'no label', 'spa': 'no label', 'ESRI_OID': 'no label', 'Shape__Are': 'no label', 'Shape__Len': 'no label', });
lyr_Metro_2023_1.set('fieldLabels', {'fid': 'no label', 'VAR_ROUTE': 'no label', 'VAR_IDENT': 'no label', 'VAR_DIREC': 'no label', 'VAR_DESCR': 'no label', 'layer': 'no label', 'path': 'no label', 'year': 'no label', });
lyr_Bus_2023_2.set('fieldLabels', {'fid': 'no label', 'Id': 'no label', 'shape_id': 'no label', 'route_id': 'no label', 'agency_id': 'no label', 'rt_shrt_nm': 'no label', 'rt_long_nm': 'no label', 'route_desc': 'no label', 'route_type': 'no label', 'rt_typ_txt': 'no label', 'route_url': 'no label', 'rt_color': 'no label', 'rt_col_fmt': 'no label', 'rt_txt_col': 'no label', 'rt_txt_fmt': 'no label', 'OBJECTID': 'no label', 'SHAPE_Leng': 'no label', 'layer': 'no label', 'path': 'no label', });
lyr_Bus_2023_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});